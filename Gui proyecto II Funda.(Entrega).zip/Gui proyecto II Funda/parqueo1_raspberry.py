"""
PARQUEO INTELIGENTE - RASPBERRY PI 1 (PARQUEO 1)
===============================================
Puerto: 1718
Espacios: 2 (Espacio 1 y 2 del Parqueo 1)
Componentes del sistema:
- Display 7 segmentos: Tarifa de parqueo (₡1000)
- Botones: Ingreso y Pago/Salida
- Fotoresistencias: Detección de ocupación de espacios
- LEDs: Indicadores de ocupación de espacios (LED ON = ocupado)
- Servomotor: Control de barrera de entrada/salida
- Comunicación WiFi: Control remoto desde GUI
"""

from machine import Pin, PWM, ADC
import time
import socket
import network
import json
import _thread

# ========== CONFIGURACIÓN DE RED ==========
SSID = "Susy"
PASSWORD = "JaimeMoya"
PUERTO_SERVIDOR = 1718  # Puerto específico para Parqueo 1
PARQUEO_ID = 1

# ========== CONFIGURACIÓN DE PINES ==========
# Servomotor (barrera)
SERVO_PIN = 26 #adc0

# Display 7 segmentos (ánodo común)
DISPLAY_PINS = {
    'a': 13,   # Segmento A
    'b': 12,   # Segmento B
    'c': 11,   # Segmento C
    'd': 10,   # Segmento D
    'e': 9,   # Segmento E
    'f': 21,   # Segmento F
    'g': 22,   # Segmento G
       # Punto decimal (no  se usa)
}

# Botones
BOTON_INGRESO = 17
BOTON_PAGO = 14

# LEDs indicadores de espacios
LED_ESPACIO_1 = 15
LED_ESPACIO_2 = 16

# Fotoresistencias (ADC)
FOTO_ESPACIO_1 = 28  # ADC0
FOTO_ESPACIO_2 = 27 # ADC1

# ========== CONFIGURACIÓN DE TARIFAS ==========
TARIFA_POR_10_SEGUNDOS = 1000  # Colones
UMBRAL_FOTORESISTENCIA = 1000  # Valor para detectar ocupación (valores MENORES = libre sin luz)

# ========== PATRONES PARA DISPLAY 7 SEGMENTOS ==========
# Patrones para números 0-9 (ánodo común - 0=encendido, 1=apagado)
DIGITOS_7SEG = {
    0: {'a': 0, 'b': 0, 'c': 0, 'd': 0, 'e': 0, 'f': 0, 'g': 1},  # 0
    1: {'a': 1, 'b': 0, 'c': 0, 'd': 1, 'e': 1, 'f': 1, 'g': 1},  # 1
    2: {'a': 0, 'b': 0, 'c': 1, 'd': 0, 'e': 0, 'f': 1, 'g': 0},  # 2
    3: {'a': 0, 'b': 0, 'c': 0, 'd': 0, 'e': 1, 'f': 1, 'g': 0},  # 3
    4: {'a': 1, 'b': 0, 'c': 0, 'd': 1, 'e': 1, 'f': 0, 'g': 0},  # 4
    5: {'a': 0, 'b': 1, 'c': 0, 'd': 0, 'e': 1, 'f': 0, 'g': 0},  # 5
    6: {'a': 0, 'b': 1, 'c': 0, 'd': 0, 'e': 0, 'f': 0, 'g': 0},  # 6
    7: {'a': 0, 'b': 0, 'c': 0, 'd': 1, 'e': 1, 'f': 1, 'g': 1},  # 7
    8: {'a': 0, 'b': 0, 'c': 0, 'd': 0, 'e': 0, 'f': 0, 'g': 0},  # 8
    9: {'a': 0, 'b': 0, 'c': 0, 'd': 0, 'e': 1, 'f': 0, 'g': 0}   # 9
}

class ParqueoInteligente1:
    """Clase principal para manejar el Parqueo 1"""
    
    def __init__(self):
        self.espacios_disponibles = 2
        self.barrera_abierta = False
        self.vehiculos_activos = {}  # ID_temp -> tiempo_entrada
        self.modo_pago = False
        self.vehiculo_en_proceso_pago = False  # Estado para el flujo de pago
        self.tiempo_entrada_vehiculo = None  # Tiempo de entrada del vehículo actual
        self.tiempo_inicio_tarifa = time.time()  # Tiempo de inicio para la tarifa
        self.bloques_transcurridos = 1  # Empieza en 1 (₡1000)
        # Control remoto de LEDs (se superpone a fotoceldas)
        self.control_manual_led1 = False  # True = control manual activo
        self.control_manual_led2 = False  # True = control manual activo
        self.estado_manual_led1 = False  # Estado cuando está en control manual
        self.estado_manual_led2 = False  # Estado cuando está en control manual
        self.inicializar_hardware()
        
    def inicializar_hardware(self):
        """Inicializar todos los componentes de hardware"""
        print(f"Inicializando hardware del Parqueo {PARQUEO_ID}...")
        
        # Servomotor
        self.servo = PWM(Pin(SERVO_PIN))
        self.servo.freq(50)
        self.servo.duty_ns(1700000)  # Posición cerrada inicial
        
        # Display 7 segmentos
        self.display_pins = {}
        for segmento, pin_num in DISPLAY_PINS.items():
            self.display_pins[segmento] = Pin(pin_num, Pin.OUT)
            self.display_pins[segmento].value(1)  # Apagar todos los segmentos
        
        # Botones (con pull-up interno)
        self.boton_ingreso = Pin(BOTON_INGRESO, Pin.IN, Pin.PULL_UP)
        self.boton_pago = Pin(BOTON_PAGO, Pin.IN, Pin.PULL_UP)
        
        # LEDs
        self.led_espacio1 = Pin(LED_ESPACIO_1, Pin.OUT)
        self.led_espacio2 = Pin(LED_ESPACIO_2, Pin.OUT)
        
        # Fotoresistencias (ADC)
        self.foto_espacio1 = ADC(Pin(FOTO_ESPACIO_1))
        self.foto_espacio2 = ADC(Pin(FOTO_ESPACIO_2))
        
        # Estado inicial
        self.actualizar_leds()
        self.mostrar_espacios_disponibles()
        
        print(f"Hardware del Parqueo {PARQUEO_ID} inicializado correctamente")
    
    def mostrar_en_display(self, numero):
        """Mostrar número en display 7 segmentos (0-9)"""
        if numero < 0 or numero > 9:
            numero = 0
            
        patron = DIGITOS_7SEG[numero]
        
        for segmento in ['a', 'b', 'c', 'd', 'e', 'f', 'g']:
            self.display_pins[segmento].value(patron[segmento])
    
    def mostrar_espacios_disponibles(self):
        """Mostrar espacios disponibles en el display"""
        self.mostrar_en_display(self.espacios_disponibles)
        print(f"Parqueo {PARQUEO_ID} - Display: {self.espacios_disponibles} espacios disponibles")
    
    def mostrar_tarifa(self):
        """Mostrar tarifa acumulada en el display (número de bloques de ₡1000)"""
        # Mostrar el número de bloques tarifarios (cada bloque = ₡1000)
        self.mostrar_en_display(min(9, self.bloques_transcurridos))  # Máximo 9 en display
        print(f"Parqueo {PARQUEO_ID} - Display tarifa: {self.bloques_transcurridos} bloques (₡{self.bloques_transcurridos * TARIFA_POR_10_SEGUNDOS})")
    
    def leer_fotoresistencias(self):
        """Leer estado de las fotoresistencias"""
        valor1 = self.foto_espacio1.read_u16()
        valor2 = self.foto_espacio2.read_u16()
        
        # Debug: Imprimir valores de las fotoceldas
        print(f"Parqueo {PARQUEO_ID} - Fotoceldas: Espacio1={valor1}, Espacio2={valor2} (Umbral={UMBRAL_FOTORESISTENCIA})")
        
        # True = ocupado, False = libre
        # Con umbral 1000: valores MENORES = libre (sin luz), valores MAYORES = ocupado (con luz)
        ocupado1 = valor1 > UMBRAL_FOTORESISTENCIA  # Si hay mucha luz = ocupado
        ocupado2 = valor2 > UMBRAL_FOTORESISTENCIA  # Si hay mucha luz = ocupado
        
        print(f"Parqueo {PARQUEO_ID} - Estados: Espacio1={'OCUPADO' if ocupado1 else 'LIBRE'}, Espacio2={'OCUPADO' if ocupado2 else 'LIBRE'}")
        
        return ocupado1, ocupado2
    
    def actualizar_leds(self):
        """Actualizar LEDs según control manual o fotoceldas (manual tiene prioridad)"""
        ocupado1, ocupado2 = self.leer_fotoresistencias()
        
        # Control manual tiene prioridad sobre fotoceldas
        if self.control_manual_led1:
            # LED 1 en control manual - usar estado manual
            self.led_espacio1.value(1 if self.estado_manual_led1 else 0)
            led1_ocupado = not self.estado_manual_led1  # Invertir para cálculo
        else:
            # LED 1 automático - usar fotocelda
            self.led_espacio1.value(0 if ocupado1 else 1)
            led1_ocupado = ocupado1
        
        if self.control_manual_led2:
            # LED 2 en control manual - usar estado manual
            self.led_espacio2.value(1 if self.estado_manual_led2 else 0)
            led2_ocupado = not self.estado_manual_led2  # Invertir para cálculo
        else:
            # LED 2 automático - usar fotocelda
            self.led_espacio2.value(0 if ocupado2 else 1)
            led2_ocupado = ocupado2
        
        # Actualizar contador de espacios basado en estados finales de LEDs
        espacios_ocupados = sum([led1_ocupado, led2_ocupado])
        espacios_anteriores = self.espacios_disponibles
        self.espacios_disponibles = 2 - espacios_ocupados
        
        # Actualizar display con espacios disponibles
        if espacios_anteriores != self.espacios_disponibles:
            self.mostrar_espacios_disponibles()
        
        # Solo reportar cambio en espacios
        if espacios_anteriores != self.espacios_disponibles:
            print(f"Parqueo {PARQUEO_ID} - Espacios disponibles actualizados: {self.espacios_disponibles}")
            print(f"Parqueo {PARQUEO_ID} - LEDs: Espacio 1={'OCUPADO (LED ON)' if ocupado1 else 'LIBRE (LED OFF)'}, Espacio 2={'OCUPADO (LED ON)' if ocupado2 else 'LIBRE (LED OFF)'}")
    
    def actualizar_tarifa_cronometro(self):
        """Actualizar el display cada 10 segundos con la tarifa acumulada"""
        tiempo_actual = time.time()
        tiempo_transcurrido = tiempo_actual - self.tiempo_inicio_tarifa
        
        # Calcular bloques de 10 segundos transcurridos
        nuevos_bloques = max(1, int(tiempo_transcurrido // 10) + 1)
        
        # Si cambió el número de bloques, actualizar display
        if nuevos_bloques != self.bloques_transcurridos:
            self.bloques_transcurridos = nuevos_bloques
            self.mostrar_tarifa()
    
    def abrir_barrera(self):
        """Abrir barrera del parqueo"""
        print(f"Parqueo {PARQUEO_ID} - Abriendo barrera...")
        self.servo.duty_ns(800000)  # Posición abierta
        self.barrera_abierta = True
    
    def cerrar_barrera(self):
        """Cerrar barrera del parqueo"""
        print(f"Parqueo {PARQUEO_ID} - Cerrando barrera...")
        self.servo.duty_ns(1700000)  # Posición cerrada
        self.barrera_abierta = False
    
    def procesar_ingreso(self):
        """BOTÓN INGRESO: Validar espacios disponibles y permitir entrada"""
        print(f"Parqueo {PARQUEO_ID} - Botón INGRESO presionado")
        
        # VALIDACIÓN: Verificar espacios disponibles
        if self.espacios_disponibles > 0:
            print(f"Parqueo {PARQUEO_ID} - ✓ ESPACIOS DISPONIBLES: {self.espacios_disponibles}")
            print(f"Parqueo {PARQUEO_ID} - Abriendo barrera para ingreso...")
            
            # Registrar tiempo de entrada del vehículo
            self.tiempo_entrada_vehiculo = time.time()
            print(f"Parqueo {PARQUEO_ID} - Tiempo de entrada registrado")
            
            # Abrir barrera para permitir ingreso
            self.abrir_barrera()
            print(f"Parqueo {PARQUEO_ID} - Barrera abierta. Ingrese el vehículo")
            
            # Esperar que el vehículo pase
            time.sleep(5)
            
            # Cerrar barrera
            self.cerrar_barrera()
            print(f"Parqueo {PARQUEO_ID} - Barrera cerrada. Vehículo dentro del parqueo")
            
            return True
        else:
            print(f"Parqueo {PARQUEO_ID} - Ingreso denegado: No hay espacios disponibles")
            # Parpadear display para indicar que está lleno
            for _ in range(3):
                self.mostrar_en_display(0)
                time.sleep(0.3)
                # Mostrar espacios disponibles
                for segmento in ['a', 'b', 'c', 'd', 'e', 'f', 'g']:
                    self.display_pins[segmento].value(1)
                time.sleep(0.3)
            self.mostrar_espacios_disponibles()
            return False
    
    def calcular_costo(self, tiempo_entrada):
        """Calcular costo de parqueo"""
        tiempo_estancia = time.time() - tiempo_entrada
        bloques_10_segundos = max(1, int(tiempo_estancia // 10) + (1 if tiempo_estancia % 10 > 0 else 0))
        costo = bloques_10_segundos * TARIFA_POR_10_SEGUNDOS
        return costo, tiempo_estancia
    
    def procesar_pago(self):
        """BOTÓN PAGO: Primera presión muestra monto, segunda presión permite salida"""
        print(f"Parqueo {PARQUEO_ID} - Botón PAGO presionado")
        
        if not self.vehiculo_en_proceso_pago:
            # === PRIMERA PRESIÓN: Mostrar monto a pagar en display 7 segmentos ===
            if self.tiempo_entrada_vehiculo is not None:
                tiempo_estancia = time.time() - self.tiempo_entrada_vehiculo
                bloques = max(1, int(tiempo_estancia // 10) + (1 if tiempo_estancia % 10 > 0 else 0))
                costo = bloques * TARIFA_POR_10_SEGUNDOS
                
                print(f"Parqueo {PARQUEO_ID} - === PRIMERA PRESIÓN: MOSTRAR TARIFA ===")
                print(f"Parqueo {PARQUEO_ID} - MONTO A PAGAR: ₡{costo} ({bloques} bloques)")
                print(f"Parqueo {PARQUEO_ID} - Tiempo en parqueo: {int(tiempo_estancia)} segundos")
                print(f"Parqueo {PARQUEO_ID} - DISPLAY 7 SEGMENTOS: {min(bloques, 9)}")
                print(f"Parqueo {PARQUEO_ID} - Presione PAGO nuevamente para confirmar y salir")
                
                # Mostrar el monto en bloques en el display 7 segmentos
                self.mostrar_en_display(min(bloques, 9))
                
                # Cambiar a modo de confirmación de pago
                self.vehiculo_en_proceso_pago = True
                
            else:
                print(f"Parqueo {PARQUEO_ID} - ERROR: No hay registro de entrada de vehículo")
                print(f"Parqueo {PARQUEO_ID} - Use el botón de INGRESO primero para registrar la entrada del vehículo")
                
        else:
            # === SEGUNDA PRESIÓN: Confirmar pago y permitir salida ===
            print(f"Parqueo {PARQUEO_ID} - === SEGUNDA PRESIÓN: CONFIRMAR PAGO Y SALIR ===")
            print(f"Parqueo {PARQUEO_ID} - Pago confirmado. Abriendo barrera para salida...")
            
            # Abrir barrera para salida
            self.abrir_barrera()
            print(f"Parqueo {PARQUEO_ID} - Barrera abierta. Retire su vehículo")
            
            # Esperar que el vehículo salga completamente
            time.sleep(5)
            
            # Cerrar barrera y limpiar estados
            self.cerrar_barrera()
            print(f"Parqueo {PARQUEO_ID} - Barrera cerrada. Vehículo ha salido")
            print(f"Parqueo {PARQUEO_ID} - Transacción completada. Gracias por usar el parqueo")
            
            # Resetear todas las variables del vehículo
            self.vehiculo_en_proceso_pago = False
            self.tiempo_entrada_vehiculo = None
            
            # Volver a mostrar espacios disponibles en display
            self.mostrar_espacios_disponibles()
            print(f"Parqueo {PARQUEO_ID} - Sistema listo para próximo vehículo")
            
        return True
    
    def monitorear_botones(self):
        """Monitorear presión de botones"""
        estado_anterior_ingreso = 1
        estado_anterior_pago = 1
        
        while True:
            # Leer estado actual de botones
            estado_ingreso = self.boton_ingreso.value()
            estado_pago = self.boton_pago.value()
            
            # Detectar presión del botón de ingreso (flanco descendente)
            if estado_anterior_ingreso == 1 and estado_ingreso == 0:
                print(f"Parqueo {PARQUEO_ID} - Botón de INGRESO presionado")
                self.procesar_ingreso()
                time.sleep(0.5)  # Debounce
            
            # Detectar presión del botón de pago (flanco descendente)
            if estado_anterior_pago == 1 and estado_pago == 0:
                print(f"Parqueo {PARQUEO_ID} - Botón de PAGO presionado")
                self.procesar_pago()
                time.sleep(0.5)  # Debounce
            
            estado_anterior_ingreso = estado_ingreso
            estado_anterior_pago = estado_pago
            
            # Actualizar LEDs periódicamente
            self.actualizar_leds()
            
            time.sleep(0.1)
    
    def conectar_wifi(self):
        """Conectar a WiFi"""
        wlan = network.WLAN(network.STA_IF)
        wlan.active(True)
        
        if not wlan.isconnected():
            print("Conectando a WiFi...")
            wlan.connect(SSID, PASSWORD)
            
            for i in range(20):
                if wlan.isconnected():
                    break
                print(".", end="")
                time.sleep(0.5)
            
            if wlan.isconnected():
                ip = wlan.ifconfig()[0]
                print(f"\nParqueo {PARQUEO_ID} conectado a WiFi. IP: {ip}")
                return ip
            else:
                print("\nNo se pudo conectar a la red WiFi.")
                return None
        else:
            ip = wlan.ifconfig()[0]
            print(f"Parqueo {PARQUEO_ID} ya conectado a WiFi. IP: {ip}")
            return ip
    
    def procesar_comando_remoto(self, comando):
        """Procesar comandos desde la aplicación GUI remota"""
        comando = comando.strip().upper()
        print(f"Parqueo {PARQUEO_ID} - Comando remoto recibido: {comando}")
        
        if comando == "SUBIR":
            self.abrir_barrera()
            return f"Parqueo {PARQUEO_ID} - Barrera abierta remotamente"
            
        elif comando == "BAJAR":
            self.cerrar_barrera()
            return f"Parqueo {PARQUEO_ID} - Barrera cerrada remotamente"
            
        elif comando == "ABRIR_PASO":
            self.abrir_barrera()
            time.sleep(3)
            self.cerrar_barrera()
            return f"Parqueo {PARQUEO_ID} - Secuencia de paso completada"
            
        elif comando == "ESTADO":
            ocupado1, ocupado2 = self.leer_fotoresistencias()
            estado = {
                "parqueo_id": PARQUEO_ID,
                "espacios_disponibles": self.espacios_disponibles,
                "vehiculos_activos": len(self.vehiculos_activos),
                "espacio1_ocupado": ocupado1,
                "espacio2_ocupado": ocupado2,
                "barrera_abierta": self.barrera_abierta,
                "modo_pago": self.modo_pago
            }
            return json.dumps(estado)
            
        elif comando == "INGRESO_REMOTO":
            if self.procesar_ingreso():
                return f"Parqueo {PARQUEO_ID} - Ingreso remoto procesado exitosamente"
            else:
                return f"Parqueo {PARQUEO_ID} - Ingreso remoto denegado - Sin espacios disponibles"
                
        elif comando == "PAGO_REMOTO":
            if self.procesar_pago():
                return f"Parqueo {PARQUEO_ID} - Pago remoto procesado exitosamente"
            else:
                return f"Parqueo {PARQUEO_ID} - No hay vehículos para procesar pago"
                
        elif comando == "OCUPAR_ESPACIO":
            # Simular ocupación física forzando LED apagado
            if self.espacios_disponibles > 0:
                # Encontrar primer espacio libre y ocuparlo
                if self.led_espacio1.value():  # Si LED1 está encendido (espacio libre)
                    self.led_espacio1.value(0)  # Apagar LED (ocupado)
                elif self.led_espacio2.value():  # Si LED2 está encendido (espacio libre)
                    self.led_espacio2.value(0)  # Apagar LED (ocupado)
                
                # Recalcular espacios disponibles
                espacios_ocupados = (1 if not self.led_espacio1.value() else 0) + (1 if not self.led_espacio2.value() else 0)
                self.espacios_disponibles = 2 - espacios_ocupados
                self.mostrar_espacios_disponibles()
                return f"Parqueo {PARQUEO_ID} - Espacio ocupado digitalmente. Disponibles: {self.espacios_disponibles}"
            else:
                return f"Parqueo {PARQUEO_ID} - No hay espacios disponibles para ocupar"
                
        elif comando == "LIBERAR_ESPACIO":
            # Liberar primer espacio ocupado
            if self.espacios_disponibles < 2:
                # Encontrar primer espacio ocupado y liberarlo
                if not self.led_espacio1.value():  # Si LED1 está apagado (ocupado)
                    self.led_espacio1.value(1)  # Encender LED (libre)
                elif not self.led_espacio2.value():  # Si LED2 está apagado (ocupado)
                    self.led_espacio2.value(1)  # Encender LED (libre)
                
                # Recalcular espacios disponibles
                espacios_ocupados = (1 if not self.led_espacio1.value() else 0) + (1 if not self.led_espacio2.value() else 0)
                self.espacios_disponibles = 2 - espacios_ocupados
                self.mostrar_espacios_disponibles()
                return f"Parqueo {PARQUEO_ID} - Espacio liberado digitalmente. Disponibles: {self.espacios_disponibles}"
            else:
                return f"Parqueo {PARQUEO_ID} - No hay espacios ocupados para liberar"
        
        elif comando.startswith("TOGGLE_LED_"):
            # Control individual de LEDs: TOGGLE_LED_1 o TOGGLE_LED_2
            try:
                espacio = int(comando.split("_")[2])  # Extraer número del espacio
                if espacio == 1:
                    self.control_manual_led1 = True
                    self.estado_manual_led1 = not self.estado_manual_led1
                    estado_str = "LIBRE" if self.estado_manual_led1 else "OCUPADO"
                    self.actualizar_leds()  # Aplicar cambios
                    return f"Parqueo {PARQUEO_ID} - LED Espacio 1 controlado manualmente: {estado_str}"
                elif espacio == 2:
                    self.control_manual_led2 = True
                    self.estado_manual_led2 = not self.estado_manual_led2
                    estado_str = "LIBRE" if self.estado_manual_led2 else "OCUPADO"
                    self.actualizar_leds()  # Aplicar cambios
                    return f"Parqueo {PARQUEO_ID} - LED Espacio 2 controlado manualmente: {estado_str}"
                else:
                    return f"Parqueo {PARQUEO_ID} - Espacio inválido: {espacio}"
            except (IndexError, ValueError):
                return f"Parqueo {PARQUEO_ID} - Comando LED inválido: {comando}"
        
        elif comando == "RESET_CONTROL_MANUAL":
            # Desactivar control manual y volver a automático
            self.control_manual_led1 = False
            self.control_manual_led2 = False
            self.actualizar_leds()  # Aplicar control automático
            return f"Parqueo {PARQUEO_ID} - Control manual desactivado. LEDs en modo automático"
                
        else:
            return f"Parqueo {PARQUEO_ID} - Comando no reconocido: {comando}"
    
    def servidor_remoto(self):
        """Servidor para comunicación remota con GUI"""
        ip = self.conectar_wifi()
        if not ip:
            print(f"Parqueo {PARQUEO_ID} - No se pudo establecer conexión WiFi para servidor remoto")
            return
        
        s = socket.socket()
        s.bind(('', PUERTO_SERVIDOR))
        s.listen(1)
        print(f"Parqueo {PARQUEO_ID} - Servidor remoto iniciado en {ip}:{PUERTO_SERVIDOR}")
        
        while True:
            try:
                conn, addr = s.accept()
                print(f"Parqueo {PARQUEO_ID} - Cliente remoto conectado desde: {addr}")
                
                while True:
                    data = conn.recv(1024)
                    if not data:
                        break
                    
                    comando = data.decode('utf-8').strip()
                    respuesta = self.procesar_comando_remoto(comando)
                    conn.send(respuesta.encode('utf-8'))
                
                conn.close()
                print(f"Parqueo {PARQUEO_ID} - Cliente remoto desconectado")
                
            except Exception as e:
                print(f"Parqueo {PARQUEO_ID} - Error en servidor remoto: {e}")
                time.sleep(1)
    
    def ejecutar(self):
        """Ejecutar el sistema completo"""
        print("INICIANDO PARQUEO INTELIGENTE 1")
        print("=" * 40)
        print("Componentes:")
        print("Display 7 segmentos - Espacios disponibles")
        print("Botón INGRESO - Solicitar entrada")  
        print("Botón PAGO - Mostrar costo y salir")
        print("LEDs - Indicadores de espacios")
        print("Fotoresistencias - Detección de ocupación")
        print("Servomotor - Control de barrera")
        print("WiFi - Control remoto")
        print(f"Puerto: {PUERTO_SERVIDOR}")
        print("=" * 40)
        
        # Iniciar servidor remoto en hilo separado
        try:
            _thread.start_new_thread(self.servidor_remoto, ())
            print(f"Parqueo {PARQUEO_ID} - Servidor remoto iniciado en hilo separado")
        except Exception as e:
            print(f"Parqueo {PARQUEO_ID} - Error iniciando servidor remoto: {e}")
        
        # Bucle principal - monitoreo de botones
        print(f"Parqueo {PARQUEO_ID} - Sistema listo. Monitoreando botones...")
        self.monitorear_botones()

# ========== FUNCIÓN PRINCIPAL ==========
def main():
    """Función principal"""
    try:
        parqueo = ParqueoInteligente1()
        parqueo.ejecutar()
    except KeyboardInterrupt:
        print(f"\nParqueo {PARQUEO_ID} - Sistema detenido por el usuario")
    except Exception as e:
        print(f"Parqueo {PARQUEO_ID} - Error crítico: {e}")
    finally:
        print(f"Parqueo {PARQUEO_ID} - Limpiando recursos...")

if __name__ == "__main__":
    main()